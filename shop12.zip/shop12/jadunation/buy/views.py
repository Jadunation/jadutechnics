from django.shortcuts import render, redirect
from .models import Product
from django.shortcuts import get_object_or_404
from django.contrib.auth.decorators import login_required

@login_required
def add_product(request):
    if request.method == "POST":
        name = request.POST['name']
        quantity = int(request.POST['quantity'])
        price = float(request.POST['price'])
        total_cost = quantity * price
        Product.objects.create(name=name, quantity=quantity, price=price, total_cost=total_cost)
        return redirect('add_product')

    products = Product.objects.all()
    
    # Calculate the total cost of all products
    total_cost_of_products = sum(product.total_cost for product in products)

    return render(request, 'buy/add.html', {'products': products, 'total_cost': total_cost_of_products})

  
@login_required
def edit_product(request, id):
    product = get_object_or_404(Product, id=id)
    
    if request.method == "POST":
        product.name = request.POST['name']
        product.quantity = int(request.POST['quantity'])
        product.price = float(request.POST['price'])
        product.total_cost = product.quantity * product.price
        product.save()
        return redirect('add_product')

    return render(request, 'buy/edit.html', {'product': product})
@login_required
def delete_product(request, id):
    product = get_object_or_404(Product, id=id)
    product.delete()
    return redirect('add_product')