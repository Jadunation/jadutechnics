from django.urls import path
from .views import home_view,login_view,add_user, sales_history, available_sales, available_products, view_users, edit_user, delete_user,manager_dashboard

app_name='admin_app'

urlpatterns = [
    path('', home_view, name='home'),
    path('login/', login_view, name='login'),
    path('dashboard/', manager_dashboard, name='manager_dashboard'),
    path('add_user/', add_user, name='add_user'),
    path('sales/', sales_history, name='sales_history'),
    path('available_sales/', available_sales, name='available_sales'),
    path('available_products/', available_products, name='available_products'),
    path('view_users/', view_users, name='view_users'),
    path('edit_user/<int:user_id>/', edit_user, name='edit_user'),
    path('delete_user/<int:user_id>/', delete_user, name='delete_user'),
]