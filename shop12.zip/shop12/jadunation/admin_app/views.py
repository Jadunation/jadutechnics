from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from sell.models import Sale  # Import Sale from the sell app
from buy.models import Product  # Import Product from the buy app
from .models import UserProfile
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth.decorators import login_required


def home_view(request):
    return render(request, 'admin_app/home.html')


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            # Redirect based on user type
            if user.userprofile.user_type == 'manager':
                return redirect('admin_app:manager_dashboard')
            elif user.userprofile.user_type == 'seller':
                return redirect('sell:sell_product')
            elif user.userprofile.user_type == 'storeman':
                return redirect('buy:add_product')
        else:
            messages.error(request, "You are not a user. Please contact the manager to add you.")
    
    return render(request, 'admin_app/login.html')

@login_required
def manager_dashboard(request):
    return render(request, 'admin_app/manager_dashboard.html')

@login_required
def add_user(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']
        phone_number = request.POST['phone_number']
        date_of_birth = request.POST['date_of_birth']
        user_type = request.POST['user_type']

        if password == confirm_password:
            # Check if the user already exists
            if User.objects.filter(username=username).exists():
                error_message = "Username already exists. Please choose another."
                return render(request, 'admin_app/add_user.html', {'error_message': error_message})

            user = User.objects.create_user(username=username, email=email, password=password)
            UserProfile.objects.create(
                user=user,
                phone_number=phone_number,
                date_of_birth=date_of_birth,
                user_type=user_type
            )
            return redirect('sales_history')
        else:
            error_message = "Passwords do not match."
            return render(request, 'admin_app/add_user.html', {'error_message': error_message})

    return render(request, 'admin_app/add_user.html')
@login_required
def view_users(request):
    users = User.objects.all()
    return render(request, 'admin_app/view_users.html', {'users': users})

def edit_user(request, user_id):
    user = get_object_or_404(User, id=user_id)
    user_profile = user.userprofile

    if request.method == 'POST':
        user.username = request.POST['username']
        user.email = request.POST['email']
        user_profile.phone_number = request.POST['phone_number']
        user_profile.date_of_birth = request.POST['date_of_birth']
        user_profile.user_type = request.POST['user_type']

        user.save()
        user_profile.save()
        return redirect('view_users')

    return render(request, 'admin_app/edit_user.html', {'user': user, 'user_profile': user_profile})

def delete_user(request, user_id):
    user = get_object_or_404(User, id=user_id)
    if request.method == 'POST':
        user.delete()
        return redirect('view_users')

    return render(request, 'admin_app/delete_user.html', {'user': user})
@login_required
def sales_history(request):
    sales = Sale.objects.all()
    return render(request, 'admin_app/sales_history.html', {'sales': sales})
@login_required
def available_sales(request):
    sales = Sale.objects.all()
    return render(request, 'admin_app/available_sales.html', {'sales': sales})
@login_required
def available_products(request):
    products = Product.objects.all()
    return render(request, 'admin_app/available_products.html', {'products': products})

