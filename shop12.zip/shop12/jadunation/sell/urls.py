# In your app's urls.py
from django.urls import path
from .views import sell_product

app_name='sell'
urlpatterns = [
    path('', sell_product, name='sell_product'),  # Handles GET and POST for selling
]