from django.shortcuts import render, redirect, get_object_or_404
from .models import Sale
from buy.models import Product
from django.contrib.auth.decorators import login_required

@login_required
def sell_product(request):
    if request.method == "POST":
        if 'add_sale' in request.POST:
            product_id = request.POST['product_id']
            quantity = int(request.POST['quantity'])
            customer_name = request.POST['customer_name']

            try:
                product = Product.objects.get(id=product_id)
                if product.quantity >= quantity:
                    total_cost = quantity * product.price
                    Sale.objects.create(
                        product=product, 
                        quantity_sold=quantity, 
                        customer_name=customer_name, 
                        total_cost=total_cost
                    )
                    product.quantity -= quantity
                    product.save()
                else:
                    # Handle insufficient stock (optional)
                    pass
            except Product.DoesNotExist:
                # Handle the case where the product doesn't exist (optional)
                pass

        elif 'edit_sale' in request.POST:
            sale_id = request.POST['sale_id']
            new_quantity = int(request.POST.get('new_quantity', 0))

            sale = get_object_or_404(Sale, id=sale_id)
            product = sale.product

            if product.quantity + sale.quantity_sold >= new_quantity:
                product.quantity += sale.quantity_sold
                product.quantity -= new_quantity
                product.save()
                
                sale.quantity_sold = new_quantity
                sale.total_cost = new_quantity * product.price
                sale.save()

        elif 'delete_sale' in request.POST:
            sale_id = request.POST['sale_id']
            sale = get_object_or_404(Sale, id=sale_id)
            product = sale.product
            product.quantity += sale.quantity_sold
            product.save()
            sale.delete()

        return redirect('sell:sell_product')

    # Fetch all products and sales
    products = Product.objects.all()
    sales = Sale.objects.all()

    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        sales = sales.filter(product__name__icontains=search_query)

    # Sort functionality
    sort_by = request.GET.get('sort', 'created_at')  # Default sort is by created_at
    if sort_by == 'customer_name':
        sales = sales.order_by('customer_name')
    elif sort_by == 'total_cost':
        sales = sales.order_by('total_cost')
    else:
        sales = sales.order_by('-created_at')  # Most recent first

    # Group sales by customer name
    sales_by_customer = {}
    for sale in sales:
        if sale.customer_name not in sales_by_customer:
            sales_by_customer[sale.customer_name] = []
        sales_by_customer[sale.customer_name].append(sale)

    # Prepare total cost per customer
    total_cost_by_customer = {}
    for customer, sales in sales_by_customer.items():
        total_cost_by_customer[customer] = sum(sale.total_cost for sale in sales)

    return render(request, 'sell/sell.html', {
        'products': products,
        'sales_by_customer': sales_by_customer,
        'total_cost_by_customer': total_cost_by_customer,
        'search_query': search_query,
        'sort_by': sort_by,
    })